/* main.c
 *
 * Copyright 2023 wb
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

//#include "config.h"
#include <glib/gi18n.h>
#include <stdio.h>

#include "GeeNotes-application.h"
#include "GeeNotes-window.h"
#include "gio/gmenumodel.h"

void set_menu_bar(GeeNotesApplication *app){
	// Load the menu UI file
  GtkBuilder *builder = gtk_builder_new_from_resource ("/org/gnome/GeeNotes/menus.ui");
  // Get the menu object
  GMenuModel *menu_model = G_MENU_MODEL (gtk_builder_get_object (builder, "menubar"));
  // Set the menu as the application menu
  gtk_application_set_menubar (GTK_APPLICATION (app), menu_model);
  // Unreference the GtkBuilder object
  g_object_unref (builder);
}

int
main (int argc, char *argv[])
{

	g_autoptr(GeeNotesApplication) app = GeeNotes_application_new ("org.gnome.GeeNotes", G_APPLICATION_FLAGS_NONE);

  // Register the application
  g_application_register (G_APPLICATION (app), NULL, NULL);

	set_menu_bar(app);

	int ret = g_application_run (G_APPLICATION (app), argc, argv);

	return ret;
}
