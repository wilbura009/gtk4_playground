/* GeeNotes-window.c
 *
 * Copyright 2023 wb
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

//#include "config.h"

#include "GeeNotes-window.h"
#include "gio/gmenu.h"

struct _GeeNotesWindow
{
  GtkApplicationWindow  parent_instance;

  // Widgets //
  GtkLabel      *message;
  GtkInfoBar    *infobar;
  GtkStatusbar  *status;
  GtkTextBuffer *buffer;
  GtkMenuButton *menubutton;
  GtkWidget     *toolmenu;
};

G_DEFINE_FINAL_TYPE (GeeNotesWindow, GeeNotes_window, GTK_TYPE_APPLICATION_WINDOW)

static void
clicked_cb(){
  return;
}

static void
update_statusbar(){
  return;
}

static void
mark_set_callback(){
  return;
}

static void
about_action (GSimpleAction *action,
              GVariant   *parameter,
              gpointer    user_data)
{
  static const char *authors[] = {"wb", NULL};
  const char *documentors[] = {"wb", NULL};

  GeeNotesWindow *self = user_data;
  g_assert (GEENOTES_IS_WINDOW (self));
  GtkWindow *window = GTK_WINDOW (self);

  gtk_show_about_dialog (window,
                         "program-name", "GeeNotes",
                         "logo-icon-name", "org.gnome.GeeNotes",
                         "authors", authors,
                         "version", "0.1.0",
                         "copyright", "© 2023 wb",
                         "license-type", GTK_LICENSE_LGPL_2_1,
                         "website", "FIXME: website",
                         "comments", "A simple note taking application",
                         "authors", authors,
                         "documenters", documentors,
                         "logo-icon-name", "org.gnome.GeeNotes",
                         "title", "GeeNotes",
                         NULL);

}

static GActionEntry win_entries[] = {
  { "about", about_action, NULL, NULL, NULL },
};


static void
GeeNotes_window_class_init (GeeNotesWindowClass *klass)
{
  GtkWidgetClass *widget_class = GTK_WIDGET_CLASS (klass);

  gtk_widget_class_set_template_from_resource (widget_class, "/org/gnome/GeeNotes/GeeNotes-window.ui");

  gtk_widget_class_bind_template_child (widget_class, GeeNotesWindow, message);
  gtk_widget_class_bind_template_child (widget_class, GeeNotesWindow, infobar);
  gtk_widget_class_bind_template_child (widget_class, GeeNotesWindow, status);
  gtk_widget_class_bind_template_child (widget_class, GeeNotesWindow, buffer);
  gtk_widget_class_bind_template_child (widget_class, GeeNotesWindow, menubutton);
  gtk_widget_class_bind_template_child (widget_class, GeeNotesWindow, toolmenu);

  gtk_widget_class_bind_template_callback (widget_class, clicked_cb);
  gtk_widget_class_bind_template_callback (widget_class, update_statusbar);
  gtk_widget_class_bind_template_callback (widget_class, mark_set_callback);
}

static void
GeeNotes_window_init (GeeNotesWindow *self)
{
  gtk_widget_init_template (GTK_WIDGET (self));
  //gtk_window_set_title (GTK_WINDOW (self), "GeeNotes");
  g_action_map_add_action_entries (G_ACTION_MAP (self),
                                   win_entries,
                                   G_N_ELEMENTS (win_entries),
                                   self);

}
