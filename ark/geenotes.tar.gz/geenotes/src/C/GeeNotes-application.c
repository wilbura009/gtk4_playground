/* GeeNotes-application.c
 *
 * Copyright 2023 wb
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

//#include "config.h"

#include "GeeNotes-application.h"
#include "GeeNotes-window.h"

struct _GeeNotesApplication
{
  GtkApplication parent_instance;
};

G_DEFINE_TYPE (GeeNotesApplication, GeeNotes_application, GTK_TYPE_APPLICATION)

GeeNotesApplication *
GeeNotes_application_new (const char        *application_id,
                             GApplicationFlags  flags)
{
  g_return_val_if_fail (application_id != NULL, NULL);

  return g_object_new (GEENOTES_TYPE_APPLICATION,
                       "application-id", application_id,
                       "flags", flags,
                       NULL);
}

static void
GeeNotes_application_activate (GApplication *app)
{
  GtkWindow *window;

  g_assert (GEENOTES_IS_APPLICATION (app));

  window = gtk_application_get_active_window (GTK_APPLICATION (app));
  if (window == NULL)
    window = g_object_new (GEENOTES_TYPE_WINDOW,
                           "application", app,
                          "show-menubar", TRUE,
                           NULL);

  gtk_window_present (window);
}

/* Helper for activate_action() */
static void
show_action_dialog (GSimpleAction *action)
{
  const char *name;
  GtkWidget *dialog;

  name = g_action_get_name (G_ACTION (action));

  dialog = gtk_message_dialog_new (NULL,
                                   GTK_DIALOG_DESTROY_WITH_PARENT,
                                   GTK_MESSAGE_INFO,
                                   GTK_BUTTONS_CLOSE,
                                   "You activated action: \"%s\"",
                                    name);

  g_signal_connect (dialog, "response",
                    G_CALLBACK (gtk_window_destroy), NULL);

  gtk_widget_show (dialog);
}

/* A simple action callback. Used as a placeholder for new actions */
static void
activate_action (GSimpleAction *action,
                 GVariant      *parameter,
                 gpointer       user_data)
{
  show_action_dialog (action);
}

/*
static void
GeeNotes_application_about_action (GSimpleAction *action,
                                      GVariant   *parameter,
                                      gpointer    user_data)
{
  static const char *authors[] = {"wb", NULL};
  GeeNotesApplication *self = user_data;
  GtkWindow *window = NULL;

  g_assert (GEENOTES_IS_APPLICATION (self));

  window = gtk_application_get_active_window (GTK_APPLICATION (self));

  gtk_show_about_dialog (window,
                         "program-name", "GeeNotes",
                         "logo-icon-name", "org.gnome.GeeNotes",
                         "authors", authors,
                         "version", "0.1.0",
                         "copyright", "© 2023 wb",
                         NULL);
}
*/


static void
GeeNotes_application_quit_action (GSimpleAction *action,
                                     GVariant   *parameter,
                                     gpointer    user_data)
{
  GeeNotesApplication *self = user_data;
  g_assert (GEENOTES_IS_APPLICATION (self));
  g_application_quit (G_APPLICATION (self));
}

static const GActionEntry app_actions[] = {
  { "new", activate_action, NULL, NULL, NULL },
  { "open", activate_action, NULL, NULL, NULL },
  { "save", activate_action, NULL, NULL, NULL },
  { "save-as", activate_action, NULL, NULL, NULL },
  { "quit", GeeNotes_application_quit_action, NULL, NULL, NULL },
};

/*
static GActionEntry win_entries[] = {
  { "about", GeeNotes_application_about_action, NULL, NULL, NULL },
  { "file1", activate_action, NULL, NULL, NULL },
  { "logo", activate_action, NULL, NULL, NULL }
};
*/


static void
GeeNotes_application_class_init (GeeNotesApplicationClass *klass)
{
  GApplicationClass *app_class = G_APPLICATION_CLASS (klass);
  app_class->activate = GeeNotes_application_activate;
}

static void
GeeNotes_application_init (GeeNotesApplication *self)
{
  // Application entries
  g_action_map_add_action_entries (G_ACTION_MAP (self),
                                   app_actions,
                                   G_N_ELEMENTS (app_actions),
                                   self);

  gtk_application_set_accels_for_action (GTK_APPLICATION (self),
                                         "app.quit",
                                         (const char *[]) { "<primary>q", NULL });
}
