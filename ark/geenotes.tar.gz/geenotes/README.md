# GeeNotes

A gtk4 note taking application.

![2023-03-03](data/screenshots/2023-03-03.png)
