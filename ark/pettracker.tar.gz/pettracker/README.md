# Pet Tracker

Track your pets.

## Features

Tracks the following data:

- weight
- age

## TODO

- [ ] create a ui file just for testing.
- [ ] create a debug class

### Other
- report bug to cambalache that if you move the project currently being worked on, then the visuals disappear. 